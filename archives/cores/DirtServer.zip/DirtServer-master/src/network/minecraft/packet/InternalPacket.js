InternalPacket = function(){
    this.buffer = false;
    this.reliability = false;
    this.hasSplit = false;
    this.messageIndex = false;
    this.orderIndex = false;
    this.orderChannel = false;
    this.splitCount = false;
    this.splitID = false;
    this.splitIndex = false;
}