DirtServer
===========
DirtServer is an MCPE server written in JavaScript. Currently only raknet is implemented. Feel free to pull request if you can make something work better.

DirtServer uses ported packet encoding and decoding from an old version of BlockServer.

### Installation
Start by cloning this repository. If you don't have git just download the ZIP and extract it as "DirtServer".
```
git clone https://github.com/Falkirks/DirtServer
```
Now install DirtServer and it's dependencies. You will need npm to do this.
```
npm install -g ./DirtServer
```
You should now be able to run DirtServer from the command line.
```
dirtserver
```
