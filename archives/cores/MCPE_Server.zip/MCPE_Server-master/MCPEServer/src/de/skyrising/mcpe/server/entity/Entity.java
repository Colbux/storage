package de.skyrising.mcpe.server.entity;

public class Entity
{

}
