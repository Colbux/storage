package com.payton;

/**
 * Created by the MineTurtle crew on 3/14/14.
 */
public class PacketTypes {

    public static final int UNCONNECTED_PING = 0x01;
    public static final int UNCONNECTED_PING_OPEN_CONNECTIONS = 0x02;
    //TODO add more packet types
}
