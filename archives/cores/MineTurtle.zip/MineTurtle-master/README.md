MineTurtle
==========

Minecraft PE Server Software in Java

primarily focused on building vanilla server software, soon to be building a plugin API.

How to run test/development versions:
===
1.) Download the jar located in /out/artifacts/payton_jar/payton.jar

2.) CD to the directory downloaded

3.) run <code>java -jar payton.jar</code>
