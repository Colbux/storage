Ideas / Todo
============

- [ ] Add some sort of tests and a CI
- [ ] Finish login sequence
- [ ] Allow players to see the world
- [ ] Allow players to chat
- [ ] Animal AI and Mobs
- [ ] Fishing
- [ ] Vehicles
- [ ] Enchantments
