mcpe-server
===========

[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Gratipay](https://img.shields.io/gratipay/mhsjlw.svg)]
(https://gratipay.com/~mhsjlw/)

An R&amp;D Minecraft PE server in Node.js

## Running / Building

    npm install
    node app.js
    

## Thanks

 - Thanks, [@Creeplays](http://github.com/creeplays) for being able to tolerate my lack of knowledge in this field and helping me with code.
 - Thanks, [@jhead](https://github.com/jhead/node-mcpe) for initial development of mcpe protocol.
