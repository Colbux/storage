/********************************************************************
	Minecraft: Pocket Edition - Decompilation Project
	Copyright (C) 2023 iProgramInCpp
	
	The following code is licensed under the BSD 1 clause license.
	SPDX-License-Identifier: BSD-1-Clause
 ********************************************************************/

#include "ChunkSource.hpp"
#include "Level.hpp"

ChunkSource::~ChunkSource()
{
}

void ChunkSource::saveAll()
{

}

#ifdef ENH_IMPROVED_SAVING
void ChunkSource::saveUnsaved()
{

}
#endif
